import {React,useState} from 'react'
import { Container, Row, Col } from 'react-grid-system';
import { BrowserRouter as Router,Route ,Switch,Link, withRouter} from "react-router-dom";
import Loginnav from './Loginnav';
import './signup.css'

function Insert() {
    return (
        <div>
            
            <Loginnav></Loginnav>
        
        <div className="box">
                <form>
                <h3>Add New data</h3>

                <div className="form-group">
                    <label>First name</label>
                    <input type="text" className="form-control" placeholder="Name" />
                </div>

                <div className="form-group">
                    <label>Last name</label>
                    <input type="text" className="form-control" placeholder="Place" />
                </div>

                

                <button type="submit" className="btn btn-primary btn-block">Insert</button>

               
            </form>
            
        </div>
        </div>
    )
}

export default withRouter(Insert)
