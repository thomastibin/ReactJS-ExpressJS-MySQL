import {React,useState} from 'react'
import { Container, Row, Col } from 'react-grid-system';
import { BrowserRouter as Router,Route ,Switch,Link, withRouter} from "react-router-dom";
import Select from 'react-select';
import './dashboard.css'
import Insert from './Insert';
import Loginnav from './Loginnav';
const namee="Tibin"

const evidenceList = [   { label: "item1", value: 1 },
    { label: "item2", value: 2 },
    { label: "item3", value: 3 },
    { label: "item4", value: 4 },
    { label: "item5", value: 5 },
    { label: "item6", value: 6 },
]

function Dashboard() {
    const [evidence, setevidence] = useState({1:{name1:"ABC",place:"kot"},2:{name1:"qwe",place:"ekm"}})
     const [fullname, setfullname] = useState("")
     const [place, setplace] = useState("")
    const choose = (e) =>{
         
        
         setfullname(evidence[e.value]["name1"])
         setplace(evidence[e.value]["place"])
         

     }

    return (
        <div>
            <Router>
            <Loginnav></Loginnav>
             
           <Container>

            <Row>
                <Col sm={12} lg={12}>
                    <h3> Welcome {namee}</h3></Col></Row>
               <br/>
                <div className='listbox'>
                    <Row>
                        <Col width={'100%'} lg={12} sm={12}> <h4>  Previously Uploaded ev  </h4>
                        </Col>
                    </Row>
                    <br></br>
                    <Row>
                        <Col width={'100%'} lg={12} sm={12}>
                            <Select options={ evidenceList }  onChange = {(e) => choose(e)}/>
                            </Col>
                    </Row>
                    <Row>
                     <div className="in">
                        <label > Name:  {fullname}</label>  <br/>
                        <label> Place  {place} </label>
                         
                         
                                   
                      
                      
                         
                     </div>

                    </Row>
                
                    
                </div>    
           </Container>
                
        
          
        <Switch>
        
     
       
      
        
           </Switch>


              </Router>
        
        
        </div>
                

               
            
    )
}

export default withRouter(Dashboard)
