import React from 'react'
import './signup.css'
import { withRouter } from 'react-router-dom'
import { useState } from 'react'

import Axios from 'axios'
function Signup() {
    const  [email, setEmail] = useState("")
    const [fn, setFirstName] = useState("")
    const [ln, setLastName] = useState("")
    const [status, setstatus] = useState("")
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    };
    const addEmployee =(e) => {
        
      //  e.preventDefault()
       
        const params = new URLSearchParams();
        params.append('email', email)
        params.append('fn', fn)
        params.append('ln', ln)
        

        Axios.post('http://localhost:3002/add-employee',params,{headers}).then((message) => {
            alert("Success"+message)}).catch( (error) => {
            
            console.error( error) })
        
    }
    return (
        <div className="box">
                <br/>  <br/>  <br/>
                <h2>{status}</h2>
                <h3>Sign Up</h3>
            <form onSubmit={addEmployee}>
                <div className="form-group">
                    <label>First name</label>
                    <input type="text" name="fn" className="form-control" placeholder="First name"  onChange={(e)=> {
                        setFirstName(e.target.value)
                    }}/>
                </div>

                <div className="form-group">
                    <label>Last name</label>
                    <input type="text" name ="ln" className="form-control" placeholder="Last name" onChange={(e)=> {
                        setLastName(e.target.value)}} />
                </div>

                <div className="form-group">
                    <label>Email address</label>
                    <input type="email" name="email" className="form-control" placeholder="Enter email" onChange={(e)=> {
                        setEmail(e.target.value)
                    }}/>
                </div>

          

                <button type="submit" className="btn btn-primary btn-block">Sign Up</button>

                <p className="forgot-password text-right">
                    
                   Already registered <a href="/sign-in">sign in?</a>
                  


                   
                   
                 
                </p>
                </form>
        </div>
    )
}

export default  withRouter(Signup)
