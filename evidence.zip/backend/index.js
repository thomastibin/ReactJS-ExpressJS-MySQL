const express=require('express')
const app=express()
const mysql= require('mysql') 

const cors=require('cors')
app.use(express.json());
app.use(express.urlencoded({
  extended: true
}));


const db=mysql.createConnection ({

    user:'root',
    host:'localhost',
    password: '',
    database: "evidence"
})

app.post('/add-employee',(req,res)=>{
    console.log("at back")
    console.log(req.body)
     
     const fn= req.body.fn;
     const ln=req.body.ln;
     const email= req.body.email
     console.log("insert into employee (email,first_name, last_name) values (?,?,?)",[email,fn,ln])
     db.query("insert into employee (email,first_name, last_name) values (?,?,?)",[email,fn,ln], (err,result)=>{
         if(err)
         {
             console.log("error")

         }
         else
         {
             res.send("values inserted")
         }
     })

})
app.listen(3002,()=> {
    console.log("Server at 3002")
})